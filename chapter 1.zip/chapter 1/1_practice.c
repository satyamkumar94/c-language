#include <stdio.h>
int main()
{
    int length = 5, breadth = 8;
    int area = length * breadth;
    printf("the area of rectengle is %d", area);
    return 0;
}