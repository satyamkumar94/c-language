#include <stdio.h>
int main()
{
    int a = 5;
    float b = 6.5;
    char c = 's';
    int d = 40;
    printf("the value of a is %d \n", a);
    printf("the value of b is %f \n", b);
    printf("the value of c is %c \n", c);
    printf(" sum of a and d is %d \n", a + d);
    return 0;
}
